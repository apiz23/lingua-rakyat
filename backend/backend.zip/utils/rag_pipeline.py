"""
rag_pipeline.py — Lightweight RAG Pipeline for Render Free Tier
===========================================================================
This version removes heavy ML dependencies (torch, transformers, sentence-transformers)
and uses Cohere API for multilingual embeddings + Groq for LLM inference.

Data Quality & Validation:
  - PDF validation before ingestion (page count, text length, corruption check)
  - Data quality metrics logged per document
  - Error handling for corrupted/malformed PDFs
  - Ingestion stats tracked for evaluation
"""

import os
import re
import time
import logging
import requests
import langdetect
from typing import Optional
from datetime import datetime
from dotenv import load_dotenv
from langchain_pinecone import PineconeVectorStore
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_groq import ChatGroq
from pypdf import PdfReader
from pinecone import Pinecone, ServerlessSpec

load_dotenv()

# ─── Logging Setup ────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("rag_pipeline")

# ─── Configuration ───────────────────────────────────────────────────────

GROQ_API_KEY   = os.getenv("GROQ_API_KEY")
GROQ_MODEL      = os.getenv("GROQ_MODEL",      "llama-3.3-70b-versatile")  # citizen chat
GROQ_MODEL_FAST = os.getenv("GROQ_MODEL_FAST", "llama-3.1-8b-instant")     # bulk eval / test suite
LLM_PROVIDER    = os.getenv("LLM_PROVIDER", "groq")

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_INDEX = os.getenv("PINECONE_INDEX", "docuquery")

# ─── Data Quality Thresholds ─────────────────────────────────────────────
MIN_TEXT_LENGTH    = 50      # minimum characters required per PDF page
MIN_PAGES          = 1       # minimum pages required in a valid PDF
MAX_PAGES          = 500     # reject unreasonably large PDFs
MIN_CHUNK_WORDS    = 20      # discard chunks shorter than this
CONFIDENCE_THRESHOLD = 0.50  # minimum retrieval score to include a source

# ─── Model-aware context budget ───────────────────────────────────────
# 413 Payload Too Large: 5 chunks x 1000 words = ~6,666 tokens > 6K limit.
# Cap context chars per model to stay safely under the TPM limit.
CONTEXT_CHAR_LIMIT_LARGE = 4000
CONTEXT_CHAR_LIMIT_SMALL = 1800
TOP_K_LARGE = 5
TOP_K_SMALL = 3

SUMMARIZE_KEYWORDS: list[str] = [
    "summarize","summarise","summary","overview","what is this document",
    "what does this document","what is this about","explain this document",
    "key takeaways","main points","give me an overview","what should i know",
    "tell me about this","describe this document","ringkaskan","ringkasan",
    "rumusan","apa isi","apakah dokumen","ceritakan","terangkan dokumen",
    "apa yang penting","kandungan dokumen","huraikan","jelaskan dokumen",
    "apa dokumen ini","总结","概述","摘要","这个文件","主要内容",
]

def is_summarize_intent(question: str) -> bool:
    q = question.lower().strip()
    return any(kw in q for kw in SUMMARIZE_KEYWORDS)

# ─── Language Detection ───────────────────────────────────────────────────

# ─── Dialect & Language Mapping ──────────────────────────────────────────────
# Maps detected language codes (including regional dialects) to the supported
# prompt language. This enables dialect-aware translation as required by Case Study 4.

DIALECT_MAP: dict[str, str] = {
    # Malay family
    "ms": "ms",   # Standard Malay
    "id": "ms",   # Indonesian → Malay (mutually intelligible)
    "zsm": "ms",  # Malay (Standard)
    # Chinese family
    "zh-cn": "zh-cn",
    "zh-tw": "zh-cn",
    "zh": "zh-cn",
    "yue": "zh-cn",  # Cantonese
    # Tagalog / Filipino
    "tl": "en",   # Tagalog → respond in English (best LLM coverage)
    "fil": "en",
    # Other SEA languages — fallback to English for now
    "th": "en",   # Thai
    "vi": "en",   # Vietnamese
    "km": "en",   # Khmer
    "lo": "en",   # Lao
    "my": "en",   # Burmese
    "jv": "ms",   # Javanese → Malay (closest supported)
    "su": "ms",   # Sundanese → Malay
    "ceb": "en",  # Cebuano → English
    "ilo": "en",  # Ilocano → English
}

# Dialect keyword triggers — if any of these words appear in the query,
# override the detected language. Useful for code-switching / mixed text.
DIALECT_KEYWORDS: dict[str, list[str]] = {
    "ms": ["nak", "boleh", "pergi", "saya", "awak", "kamu", "dia", "kami",
           "mereka", "ini", "itu", "dengan", "untuk", "tidak", "ada", "kalau",
           "mohon", "bantuan", "kerajaan", "permohonan", "kelayakan"],
    "zh-cn": ["的", "是", "了", "在", "我", "你", "他", "她", "们", "申请",
              "政府", "帮助", "如何", "怎么"],
}


def _is_small_model(model_name: str) -> bool:
    """True for models with tight TPM limits (8B, gemma, etc.)"""
    return any(p in model_name.lower() for p in ["8b","gemma","7b","9b","mixtral"])


def detect_language(text: str) -> str:
    """
    Detect language with dialect-aware mapping for SEA languages.

    Priority:
      1. Dialect keyword matching (handles code-switching)
      2. CJK Unicode block detection
      3. langdetect library
      4. Fallback → "en"
    """
    text_lower = text.lower()

    # Priority 1: dialect keyword matching
    for lang, keywords in DIALECT_KEYWORDS.items():
        if any(kw in text_lower for kw in keywords):
            logger.debug("[Lang] Keyword match → %s", lang)
            return lang

    # Priority 2: CJK character ratio
    cjk_count = sum(
        1 for c in text
        if "\u4E00" <= c <= "\u9FFF" or "\u3040" <= c <= "\u309F"
    )
    if len(text) > 0 and cjk_count / len(text) > 0.15:
        return "zh-cn"

    # Priority 3: langdetect
    try:
        detected = langdetect.detect(text)
        mapped = DIALECT_MAP.get(detected, "en")
        logger.debug("[Lang] langdetect=%s → mapped=%s", detected, mapped)
        return mapped
    except Exception:
        return "en"


# ─── Query Cache ──────────────────────────────────────────────────────────────
# Simple in-process LRU-style cache keyed on (question, document_id).
# Avoids redundant embedding + Pinecone calls for repeated questions.
# In production, replace with Redis for multi-worker deployments.

_query_cache: dict[tuple, dict] = {}
CACHE_MAX_SIZE = 200  # max entries before oldest are evicted


def _cache_key(question: str, document_id: str) -> tuple:
    return (question.strip().lower(), document_id)


def cache_get(question: str, document_id: str) -> dict | None:
    key = _cache_key(question, document_id)
    entry = _query_cache.get(key)
    if entry:
        logger.info("[Cache] HIT for question: %s", question[:60])
    return entry


def cache_set(question: str, document_id: str, result: dict) -> None:
    global _query_cache
    if len(_query_cache) >= CACHE_MAX_SIZE:
        # Evict the oldest 20% of entries
        evict_n = CACHE_MAX_SIZE // 5
        keys_to_evict = list(_query_cache.keys())[:evict_n]
        for k in keys_to_evict:
            del _query_cache[k]
        logger.info("[Cache] Evicted %d entries (size limit)", evict_n)
    _query_cache[_cache_key(question, document_id)] = result
    logger.debug("[Cache] SET for question: %s", question[:60])


def cache_invalidate_document(document_id: str) -> int:
    """Remove all cached entries for a document (call on document delete)."""
    global _query_cache
    before = len(_query_cache)
    _query_cache = {k: v for k, v in _query_cache.items() if k[1] != document_id}
    removed = before - len(_query_cache)
    if removed:
        logger.info("[Cache] Invalidated %d entries for document_id=%s", removed, document_id)
    return removed


# ─── Embedding via Cohere API ────────────────────────────────────────────────

def get_embeddings_cohere(texts: list[str], input_type: str = "search_document") -> list[list[float]]:
    """
    Get multilingual embeddings from Cohere API (embed-multilingual-v3.0, 1024-dim).

    Args:
        texts:      List of strings to embed.
        input_type: "search_document" for indexing, "search_query" for queries.
                    Using the correct type improves retrieval accuracy.
    """
    cohere_key = os.getenv("COHERE_API_KEY")
    if not cohere_key:
        raise ValueError("COHERE_API_KEY not set. Get free key at https://dashboard.cohere.com/api-keys")

    url = "https://api.cohere.ai/v1/embed"
    headers = {
        "Authorization": f"Bearer {cohere_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "texts": texts,
        "model": "embed-multilingual-v3.0",
        "input_type": input_type,
    }

    try:
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        response.raise_for_status()
        data = response.json()
        embeddings = data.get("embeddings", [])
        if not embeddings:
            logger.warning("[Embed] Empty embeddings response — returning zero vectors")
            return [[0.0] * 1024 for _ in texts]
        return embeddings
    except Exception as e:
        logger.error("[Embed] Cohere API error: %s", e)
        return [[0.0] * 1024 for _ in texts]

# ─── PDF Validation & Processing ────────────────────────────────────────

class PDFValidationError(ValueError):
    """Raised when a PDF fails quality checks before ingestion."""
    pass


def validate_pdf(pdf_path: str) -> dict:
    """
    Validate a PDF file before ingestion and return quality metrics.

    Returns a dict with:
        valid        (bool)  — whether the PDF passed all checks
        page_count   (int)   — number of pages
        char_count   (int)   — total characters extracted
        empty_pages  (int)   — pages with no extractable text
        error        (str)   — human-readable reason if invalid
    """
    metrics = {
        "valid": False,
        "page_count": 0,
        "char_count": 0,
        "empty_pages": 0,
        "avg_chars_per_page": 0.0,
        "error": None,
    }

    try:
        reader = PdfReader(pdf_path)
    except Exception as e:
        metrics["error"] = f"Cannot open PDF — file may be corrupted: {e}"
        logger.warning("[Validate] %s", metrics["error"])
        return metrics

    page_count = len(reader.pages)
    metrics["page_count"] = page_count

    if page_count < MIN_PAGES:
        metrics["error"] = f"PDF has no pages."
        logger.warning("[Validate] %s", metrics["error"])
        return metrics

    if page_count > MAX_PAGES:
        metrics["error"] = f"PDF is too large ({page_count} pages; max {MAX_PAGES})."
        logger.warning("[Validate] %s", metrics["error"])
        return metrics

    total_chars = 0
    empty_pages = 0
    for i, page in enumerate(reader.pages):
        try:
            text = page.extract_text() or ""
            text = text.strip()
            total_chars += len(text)
            if len(text) < MIN_TEXT_LENGTH:
                empty_pages += 1
        except Exception:
            empty_pages += 1

    metrics["char_count"] = total_chars
    metrics["empty_pages"] = empty_pages
    metrics["avg_chars_per_page"] = round(total_chars / max(page_count, 1), 1)

    if total_chars < MIN_TEXT_LENGTH:
        metrics["error"] = (
            "PDF appears to be a scanned image or has no extractable text. "
            "OCR support is not available in this version."
        )
        logger.warning("[Validate] %s", metrics["error"])
        return metrics

    empty_ratio = empty_pages / max(page_count, 1)
    if empty_ratio > 0.8:
        metrics["error"] = (
            f"Over 80% of pages ({empty_pages}/{page_count}) have no extractable text. "
            "The document may be scanned or image-based."
        )
        logger.warning("[Validate] %s", metrics["error"])
        return metrics

    metrics["valid"] = True
    logger.info(
        "[Validate] PDF OK — %d pages, %d chars, %d empty pages (%.0f%% empty)",
        page_count, total_chars, empty_pages, empty_ratio * 100,
    )
    return metrics


def extract_text_from_pdf(pdf_path: str) -> tuple[str, dict]:
    """
    Extract text from a validated PDF file.

    Returns:
        (text, quality_metrics) — text content and data quality report.
    Raises:
        PDFValidationError — if the PDF fails validation.
    """
    quality = validate_pdf(pdf_path)
    if not quality["valid"]:
        raise PDFValidationError(quality["error"])

    text = ""
    try:
        reader = PdfReader(pdf_path)
        for page in reader.pages:
            try:
                page_text = page.extract_text() or ""
                text += page_text + "\n"
            except Exception as e:
                logger.warning("[PDF] Could not extract page: %s", e)
    except Exception as e:
        raise PDFValidationError(f"Failed to read PDF: {e}")

    return text.strip(), quality

# ─── Chunk Text ──────────────────────────────────────────────────────────

def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200) -> list[str]:
    """
    Split text into overlapping chunks, discarding chunks that are too short.
    Chunks shorter than MIN_CHUNK_WORDS are filtered out to avoid noise.
    """
    chunks = []
    words = text.split()

    for i in range(0, len(words), chunk_size - overlap):
        chunk = " ".join(words[i:i + chunk_size])
        # Quality filter: skip very short chunks
        if len(chunk.split()) >= MIN_CHUNK_WORDS:
            chunks.append(chunk)

    logger.info("[Chunk] %d words → %d chunks (size=%d, overlap=%d)",
                len(words), len(chunks), chunk_size, overlap)
    return chunks

# ─── Ingest Document ─────────────────────────────────────────────────────

def ingest_document(pdf_path: str, document_id: str, document_name: str = None) -> int:
    """
    Validate and ingest a PDF document into Pinecone.

    Returns:
        chunk_count (int) — number of chunks stored.
    Raises:
        PDFValidationError — if the PDF fails quality checks.
        ValueError — if no text could be extracted.
    """
    logger.info("[Ingest] Starting ingestion for document_id=%s name=%s",
                document_id, document_name or "unknown")

    # Step 1 — Validate & extract (raises PDFValidationError on failure)
    text, quality_metrics = extract_text_from_pdf(pdf_path)

    logger.info(
        "[Ingest] Quality metrics: pages=%d chars=%d empty_pages=%d avg_chars/page=%.1f",
        quality_metrics["page_count"],
        quality_metrics["char_count"],
        quality_metrics["empty_pages"],
        quality_metrics["avg_chars_per_page"],
    )

    if not text:
        raise ValueError("No text extracted from PDF after validation.")

    # Step 2 — Chunk
    chunks = chunk_text(text)
    if not chunks:
        raise ValueError("Document produced no valid text chunks after filtering.")

    # Step 3 — Embed
    logger.info("[Ingest] Requesting embeddings for %d chunks…", len(chunks))
    t0 = time.time()
    embeddings = get_embeddings_cohere(chunks)
    embed_ms = round((time.time() - t0) * 1000)
    logger.info("[Ingest] Embeddings received in %dms", embed_ms)

    # Step 4 — Upsert to Pinecone
    pc = Pinecone(api_key=PINECONE_API_KEY)
    index = pc.Index(PINECONE_INDEX)

    vectors_to_upsert = [
        (
            f"{document_id}_{i}",
            embedding,
            {
                "text": chunk,
                "doc_id": document_id,
                "chunk_index": i,
                "doc_name": document_name or "",
            },
        )
        for i, (chunk, embedding) in enumerate(zip(chunks, embeddings))
    ]

    t1 = time.time()
    index.upsert(vectors=vectors_to_upsert, namespace=document_id)
    upsert_ms = round((time.time() - t1) * 1000)
    logger.info("[Ingest] Upserted %d vectors in %dms", len(chunks), upsert_ms)

    return len(chunks)

# ─── Query Document ──────────────────────────────────────────────────────

def answer_question(question: str, document_id: str, model_override: str | None = None) -> dict:
    """
    Answer a question about a document using RAG.

    Returns a dict with:
        answer      (str)   — simplified, translated AI response
        language    (str)   — detected language code
        sources     (list)  — retrieved chunks with confidence scores
        confidence  (float) — top retrieval score (0–1)
        latency_ms  (int)   — total end-to-end latency in milliseconds
    """
    t_start = time.time()

    lang = detect_language(question)
    logger.info("[Chat] Detected language=%s for question: %s", lang, question[:80])

    # ── Cache check ──────────────────────────────────────────────────────
    cached = cache_get(question, document_id)
    if cached:
        return {**cached, "cached": True}

    # ── Detect summary intent ────────────────────────────────────────────
    _is_summary = is_summarize_intent(question)
    if _is_summary:
        logger.info("[Chat] Summary intent — using broad retrieval")

    # ── Embed query ──────────────────────────────────────────────────────
    # For summaries use a generic phrase so vector search covers the whole doc
    t_embed = time.time()
    embed_text = "document overview summary key points" if _is_summary else question
    question_embedding = get_embeddings_cohere([embed_text], input_type="search_query")[0]
    embed_ms = round((time.time() - t_embed) * 1000)
    logger.info("[Chat] Query embedded in %dms", embed_ms)

    # ── Retrieve from Pinecone ───────────────────────────────────────────
    pc = Pinecone(api_key=PINECONE_API_KEY)
    index = pc.Index(PINECONE_INDEX)

    _small = _is_small_model(_model)
    # Summaries need more chunks to cover the whole document
    if _is_summary:
        _top_k = (TOP_K_SMALL + 2) if _small else (TOP_K_LARGE + 3)
    else:
        _top_k = TOP_K_SMALL if _small else TOP_K_LARGE
    t_retrieve = time.time()
    results = index.query(
        vector=question_embedding,
        top_k=_top_k,
        namespace=document_id,
        include_metadata=True,
    )
    retrieve_ms = round((time.time() - t_retrieve) * 1000)
    logger.info("[Chat] Pinecone retrieval in %dms, got %d matches",
                retrieve_ms, len(results["matches"]))

    # ── Filter by confidence threshold ───────────────────────────────────
    # Skip filter for summaries — generic embed query gives lower scores intentionally
    if _is_summary:
        filtered_matches = results["matches"]  # use all retrieved chunks
        logger.info("[Chat] Summary mode — skipping confidence filter, using all %d chunks",
                    len(filtered_matches))
    else:
        filtered_matches = [
            m for m in results["matches"] if m.get("score", 0) >= CONFIDENCE_THRESHOLD
        ]
        if not filtered_matches:
            logger.warning(
                "[Chat] All %d matches below confidence threshold %.2f — using top match anyway",
                len(results["matches"]), CONFIDENCE_THRESHOLD,
            )
            filtered_matches = results["matches"][:1]

    _char_limit = CONTEXT_CHAR_LIMIT_SMALL if _small else CONTEXT_CHAR_LIMIT_LARGE
    _chunk_limit = _char_limit // max(len(filtered_matches), 1)
    context = "\n".join([
        m["metadata"]["text"][:_chunk_limit] for m in filtered_matches
    ])
    logger.info("[Chat] ctx=%d chars (limit=%d), model=%s small=%s",
                len(context), _char_limit, _model, _small)
    logger.info("[Chat] Using %d/%d chunks (confidence ≥ %.2f)",
                len(filtered_matches), len(results["matches"]), CONFIDENCE_THRESHOLD)

    # ── Build prompt (Case Study 4: simplification + bullet-point summarization) ──
    # ── Few-shot prompted templates ──────────────────────────────────────────
    # Each prompt includes 2 worked examples (few-shot) so the LLM learns:
    #   (a) the exact bullet-point output format
    #   (b) how to simplify jargon to plain language
    #   (c) the correct source citation ending
    # This dramatically reduces format drift across different document types.
    prompts = {
        "en": (
            "You are a helpful government services assistant.\n"
            "Your job: read official documents and give simple, clear answers.\n\n"
            "RULES:\n"
            "1. Answer ONLY from the context — never make up information.\n"
            "2. Use simple, everyday words (5th-grade reading level).\n"
            "3. Replace legal/technical jargon with plain language.\n"
            "4. Format as 3-5 short bullet points — each one is one short sentence.\n"
            "5. End every answer with: Source: Based on official documents provided.\n\n"
            "--- EXAMPLE 1 ---\n"
            "Question: Who can apply for housing aid?\n"
            "Answer:\n"
            "• Malaysian citizens with a monthly income below RM3,000 can apply.\n"
            "• You must be a first-time home buyer with no other property.\n"
            "• You need to be at least 18 years old.\n"
            "Source: Based on official documents provided.\n\n"
            "--- EXAMPLE 2 ---\n"
            "Question: What documents do I need?\n"
            "Answer:\n"
            "• Bring your identity card (MyKad).\n"
            "• Prepare your latest payslip or income proof.\n"
            "• You also need a utility bill to show your address.\n"
            "Source: Based on official documents provided.\n\n"
            "--- NOW ANSWER THIS ---\n"
            "Context from official documents:\n{context}\n\n"
            "Question: {question}\n"
            "Answer:"
        ),
        "ms": (
            "Anda adalah pembantu perkhidmatan kerajaan yang membantu.\n"
            "Tugas anda: baca dokumen rasmi dan berikan jawapan yang mudah dan jelas.\n\n"
            "PERATURAN:\n"
            "1. Jawab HANYA dari konteks — jangan reka maklumat.\n"
            "2. Gunakan perkataan mudah, harian (tahap pembacaan darjah 5).\n"
            "3. Gantikan jargon undang-undang/teknikal dengan bahasa biasa.\n"
            "4. Format sebagai 3-5 mata peluru pendek — setiap satu ialah satu ayat pendek.\n"
            "5. Akhiri setiap jawapan dengan: Sumber: Berdasarkan dokumen rasmi yang disediakan.\n\n"
            "--- CONTOH 1 ---\n"
            "Soalan: Siapa yang boleh mohon bantuan perumahan?\n"
            "Jawapan:\n"
            "• Warganegara Malaysia dengan pendapatan bulanan di bawah RM3,000 boleh memohon.\n"
            "• Anda mestilah pembeli rumah pertama yang tidak memiliki harta lain.\n"
            "• Anda perlu berumur sekurang-kurangnya 18 tahun.\n"
            "Sumber: Berdasarkan dokumen rasmi yang disediakan.\n\n"
            "--- CONTOH 2 ---\n"
            "Soalan: Apakah dokumen yang diperlukan?\n"
            "Jawapan:\n"
            "• Bawa kad pengenalan anda (MyKad).\n"
            "• Sediakan slip gaji atau bukti pendapatan terkini.\n"
            "• Anda juga perlukan bil utiliti untuk tunjukkan alamat anda.\n"
            "Sumber: Berdasarkan dokumen rasmi yang disediakan.\n\n"
            "--- JAWAB SOALAN INI ---\n"
            "Konteks daripada dokumen rasmi:\n{context}\n\n"
            "Soalan: {question}\n"
            "Jawapan:"
        ),
        "zh-cn": (
            "您是一位有帮助的政府服务助理。\n"
            "您的工作：阅读官方文件，提供简单清晰的答案。\n\n"
            "规则：\n"
            "1. 只从背景回答——不要编造信息。\n"
            "2. 使用简单的日常用语（五年级阅读水平）。\n"
            "3. 用通俗语言替换法律/技术术语。\n"
            "4. 格式为3-5个简短要点——每个要点是一个简短句子。\n"
            "5. 每个答案以此结尾：来源：基于所提供的官方文件。\n\n"
            "--- 示例1 ---\n"
            "问题：谁可以申请住房援助？\n"
            "答案：\n"
            "• 月收入低于3000令吉的马来西亚公民可以申请。\n"
            "• 您必须是第一次购房且没有其他房产。\n"
            "• 您需要年满18岁。\n"
            "来源：基于所提供的官方文件。\n\n"
            "--- 示例2 ---\n"
            "问题：我需要什么文件？\n"
            "答案：\n"
            "• 携带您的身份证（MyKad）。\n"
            "• 准备最新的工资单或收入证明。\n"
            "• 您还需要水电费账单来证明您的地址。\n"
            "来源：基于所提供的官方文件。\n\n"
            "--- 现在回答这个问题 ---\n"
            "来自官方文件的背景：\n{context}\n\n"
            "问题：{question}\n"
            "答案："
        ),
    }

    if _is_summary:
        summary_prompts = {
            "en": (
                "You are a helpful government services assistant.\n"
                "Read the following excerpts from an official document and write a clear summary.\n\n"
                "Document excerpts:\n{context}\n\n"
                "INSTRUCTIONS:\n"
                "1. Write 3-5 bullet points summarising what this document is about.\n"
                "2. Each bullet must be one short simple sentence (5th-grade reading level).\n"
                "3. Mention the document purpose, who it is for, and the main points.\n"
                "4. Do NOT make up anything not in the excerpts.\n"
                "5. End with: Source: Based on official documents provided."
            ),
            "ms": (
                "Anda adalah pembantu perkhidmatan kerajaan yang membantu.\n"
                "Baca petikan daripada dokumen rasmi dan tulis ringkasan yang jelas.\n\n"
                "Petikan dokumen:\n{context}\n\n"
                "ARAHAN:\n"
                "1. Tulis 3-5 mata peluru meringkaskan apa yang dokumen ini mengenai.\n"
                "2. Setiap mata peluru mestilah satu ayat pendek dan mudah (tahap darjah 5).\n"
                "3. Nyatakan tujuan dokumen, untuk siapa, dan perkara utama.\n"
                "4. JANGAN reka maklumat yang tidak ada dalam petikan.\n"
                "5. Akhiri dengan: Sumber: Berdasarkan dokumen rasmi yang disediakan."
            ),
            "zh-cn": (
                "您是一位有帮助的政府服务助理。\n"
                "请阅读以下官方文件摘录并写一份清晰的摘要。\n\n"
                "文件摘录：\n{context}\n\n"
                "说明：\n"
                "1. 用3-5个要点总结这份文件的内容。\n"
                "2. 每个要点应为一个简短易懂的句子（五年级阅读水平）。\n"
                "3. 说明文件的目的、适用对象和主要内容。\n"
                "4. 不要编造摘录中没有的信息。\n"
                "5. 以来源：基于所提供的官方文件结尾"
            ),
        }
        prompt_text = summary_prompts.get(lang, summary_prompts["en"]).format(context=context)
    else:
        prompt_text = prompts.get(lang, prompts["en"]).format(
            context=context, question=question
        )

    # ── Generate answer (with 429 auto-fallback) ────────────────────────────
    t_llm  = time.time()
    _model = model_override or GROQ_MODEL
    logger.info("[Chat] Using model: %s", _model)

    def _call_llm(model: str) -> object:
        llm = ChatGroq(api_key=GROQ_API_KEY, model_name=model, temperature=0.3)
        return llm.invoke(prompt_text)

    try:
        response = _call_llm(_model)
    except Exception as e:
        err_str = str(e).lower()
        if "429" in err_str or "rate limit" in err_str or "too many" in err_str:
            # Primary model hit daily/minute limit — fall back to fast model
            fallback = GROQ_MODEL_FAST if _model != GROQ_MODEL_FAST else "gemma2-9b-it"
            logger.warning(
                "[Chat] 429 on %s — retrying with fallback model %s", _model, fallback
            )
            response = _call_llm(fallback)
        else:
            raise
    llm_ms = round((time.time() - t_llm) * 1000)

    total_ms = round((time.time() - t_start) * 1000)
    top_score = filtered_matches[0].get("score", 0) if filtered_matches else 0

    logger.info(
        "[Chat] Done — lang=%s confidence=%.3f latency=%dms "
        "(embed=%dms retrieve=%dms llm=%dms)",
        lang, top_score, total_ms, embed_ms, retrieve_ms, llm_ms,
    )

    result = {
        "answer": response.content,
        "language": lang,
        "sources": [
            {
                "text": m["metadata"]["text"][:200],
                "document_id": document_id,
                "score": round(m.get("score", 0), 4),
            }
            for m in filtered_matches
        ],
        "confidence": round(top_score, 4),
        "latency_ms": total_ms,
        "cached": False,
        "model_used": _model,   # which model actually answered
    }

    # Store in cache for future identical queries
    cache_set(question, document_id, result)
    return result


# ─── Delete Document ─────────────────────────────────────────────────────

def delete_document_from_vectorstore(document_id: str) -> None:
    """Delete a document namespace from Pinecone and invalidate cache."""
    try:
        pc = Pinecone(api_key=PINECONE_API_KEY)
        index = pc.Index(PINECONE_INDEX)
        index.delete(delete_all=True, namespace=document_id)
        cache_invalidate_document(document_id)
        logger.info("[RAG] Deleted namespace for document_id=%s", document_id)
    except Exception as e:
        logger.error("[RAG] Error deleting document_id=%s: %s", document_id, e)
